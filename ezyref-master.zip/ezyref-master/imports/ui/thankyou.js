import React from 'react'
export default ThankYou =(params) =>{
  return (
    <div className="well well-sm">
      <h2 className="text-center">
        Thank you! For Filling Questionnaire Form
      </h2>
    </div>
  )
}