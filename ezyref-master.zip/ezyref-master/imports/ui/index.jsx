import React from 'react'

export const Index =({}) => (<div></div>)