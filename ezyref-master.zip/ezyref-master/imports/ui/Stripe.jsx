import React,{ Component } from 'react'

export default class Stripe extends Component {
  constructor(props) {
    super(props)
  }

  render(){
    return (
      <div>
    		<h3>Stripe things</h3>
      </div>
    )
  }
}
