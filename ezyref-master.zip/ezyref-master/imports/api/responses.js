import { Mongo } from 'meteor/mongo';

export default Responses = new Mongo.Collection('responses');
