let notificationDb = new Mongo.Collection('notification')


export default notificationDb