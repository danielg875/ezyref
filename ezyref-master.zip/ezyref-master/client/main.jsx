/*import React from 'react';
import { Meteor } from 'meteor/meteor';
import { render } from 'react-dom';
import Header from './../imports/ui/Header.jsx'
import Footer from './../imports/ui/Footer.jsx'
import Index from '../imports/ui/index.jsx';
import AppContainer from '../imports/ui/AppContainer.jsx'
import Dashboard from './../imports/ui/Dashboard.jsx'
import Home from './../imports/ui/Home.jsx'
import NewPosition from './../imports/ui/NewPosition.jsx'
import NewPositionIntroduction from './../imports/ui/NewPositionIntroduction.jsx'

import { Router, Route, browserHistory, IndexRoute } from 'react-router'*/


Meteor.startup(() => {

 /* render((<Router history={ browserHistory }>
      <Route path="/" component={ AppContainer }>
        <IndexRoute component={ Home }/>
        <Route path="/dashboard" component= { Dashboard } />
        <Route path="/newposition" component= { NewPosition } />
      </Route>
    </Router>), document.getElementById('render-target'))*/
});
